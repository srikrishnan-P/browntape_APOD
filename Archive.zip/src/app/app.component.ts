import { Component } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'browntape-APOD';

  constructor(private router: Router) { }

  homeClicked() {
    this.router.navigate(['home']);
  }

  favoritesClicked() {
    this.router.navigate(['favorites']);
  }
}

export const urls = {

    "apoc": "https://api.nasa.gov/planetary/apod"

}